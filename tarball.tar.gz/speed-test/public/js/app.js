$(document).ready(function() {
    var ws = new WebSocket("ws://" + document.location.hostname + ':' + document.location.port);

    var cursor_inside_input = false;
    
    ws.onopen = function() {
    };

    var testers = {};

    function refresh_status() {
        for (var i in testers) {
            z = testers[i];
            if (z.cnt < 0)
                return;
            if (z.cnt > 0)
                z.cnt--;
            if (z.cnt == 0)
                z.status = "Stopped";
            else
                z.status = "Shooting";
        }
    }
    setInterval(refresh_status, 500);

    function get_buttons(state) {
        var btn0 = state ? "Y" : "N";
        var btn1 = state ? "N" : "Y";
        return [
            "<input class='do-start' size='10' type='button' value='" + btn0 + "'>",
            "<input class='do-stop' size='10' type='button' value='" + btn1 + "'>"
        ];
    };

    function do_send(msg) {
        ws.send(JSON.stringify(msg));
    };

    function send_val(name, type, val) {
        do_send({
            "name": name,
            "type": type,
            "val": val
        });
    };
    
    function on_start(name) {
        send_val(name, "set_status", true);
    };

    function on_stop(name) {
        send_val(name, "set_status", false);
    };

    function key_edit_started(name) {
        cursor_inside_input = true;
    };

    function on_ips(name) {
        cursor_inside_input = false;
        var val = parseInt($("#" + name + " .ips").val());
        if (val > 1000)
            val = 1000;
        send_val(name, "set_irate", val);
    };
    
    function on_qps(name) {
        cursor_inside_input = false;
        var val = parseInt($("#" + name + " .qps").val());
        if (val > 1000)
            val = 1000;
        send_val(name, "set_qrate", val);
    };
    
    
    function handle(msg) {
        //console.log(msg);
        if (msg.type == "alert")
            alert(msg.contents);
        if (msg.type == "stats") {
            for (var i in msg.contents) {
                var z = msg.contents[i];
                if (!(i in testers)) {
                    testers[i] = {status: "Zero", cnt: -1};
                    var status = testers[i].status;
                    var btns = get_buttons(z.is_processing);
                    var markup = "<tr id='" + i + "'><td>" + i +
                        "</td><td><input class='ips' type='text' value='" +
                        z.ips + "'></td><td><input class='qps' type='text' value='" + z.qps +
                        "'></td><td>" + z.comitted + "</td><td>" +
                        z.endorsed + "</td><td>" + z.queried +
                        "</td><td>" + z.lost + "</td><td>" +
                        btns[0] + "</td><td>" + btns[1] + "</td><td>" +
                        status + "</td><td>*</td></tr>";
                    $("table").append(markup);
                    $("#" + i + " .ips").blur(function() {
                        on_ips(i);
                    });
                    $("#" + i + " .ips").focus(function() {
                        key_edit_started(i);
                    });
                    $("#" + i + " .qps").blur(function() {
                        on_qps(i);
                    });
                    $("#" + i + " .qps").focus(function() {
                        key_edit_started(i);
                    });
                    $("#" + i + " .do-start").click(function() {
                        on_start(i);
                    });
                    $("#" + i + " .do-stop").click(function() {
                        on_stop(i);
                    });
                    
                } else {
                    var btns = [
                        z.is_processing ? "Y" : "N",
                        z.is_processing ? "N" : "Y"
                    ];
                    var ch = $("#" + i).children().toArray();
                    if (!cursor_inside_input) {
                        $(ch[1]).children().first().val(z.ips);
                        $(ch[2]).children().first().val(z.qps);
                    }
                    $(ch[3]).html(z.comitted);
                    $(ch[4]).html(z.endorsed);
                    $(ch[5]).html(z.queried);
                    $(ch[6]).html(z.lost);
                    $(ch[7]).children().first().val(btns[0]);
                    $(ch[8]).children().first().val(btns[1]);
                    $(ch[9]).html(testers[i].status);

                    if (z.comitted > 0 || z.endorsed > 0 ||
                        z.queried > 0)
                    testers[i].cnt = 10;
                }
            }
        }
    };

    ws.onmessage = function(msg) {
        handle(JSON.parse(msg.data));
    };

});
