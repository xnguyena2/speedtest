'use strict';

var express = require('express');
var session = require('express-session');
var serve_static = require('serve-static');
var path = require('path');
var cookieParser = require('cookie-parser');
var http = require('http');
var cors = require('cors');
var async = require('async');
var ws = require('ws');
var bodyParser = require('body-parser');

var app = express();
app.use(cookieParser());
app.use(bodyParser.urlencoded({ extended: true }));

app.use(session({ secret: 'buuu3', resave: true, saveUninitialized: true }));
app.options('*', cors());
app.use(cors());

var FabricClient = require('fabric-client');
var User = require('fabric-client/lib/User.js');
var CaService = require('fabric-ca-client/lib/FabricCAClientImpl.js');
var Orderer = require('fabric-client/lib/Orderer.js');
var Peer = require('fabric-client/lib/Peer.js');
FabricClient.setConfigSetting('request-timeout', 90000);

var HyperledgerTester = function(options) {

    var ips = 2;
    var qps = 2;
    var qdelay = 1000 / qps;
    var idelay = 1000 / ips;
    var is_processing = false;
    var client = new FabricClient();
	var channel = client.newChannel(options.channel_id);

    // if chains are live
    var iproc = false;
    var qproc = false;

    var stats = {
        queried: 0,
        comitted: 0,
        endorsed: 0,
        lost: 0
    }

    var maybe_start_iproc = function(obj) {
        if (iproc)
            return;
        var request = {
			chaincodeId: "speedt",
			fcn: "invoke",
			args: [],
			txId: null
        };

        var fn = function() {
            var txId = client.newTransactionID();
            request.txId = txId;
            obj.channel.sendTransactionProposal(request)
                .then(function(results) {
                    stats.endorsed++;
			        var request = {
				        proposalResponses: results[0],
				        proposal: results[1],
				        header: results[2]
			        };
			        return channel.sendTransaction(request);
                })
                .then((response_payloads) => {
                    //if (response.status === 'SUCCESS') {
                    stats.comitted++;
                    if (is_processing)
                        setTimeout(fn, idelay);
                    else
                        iproc = false;
                })
                .catch(function (err) {
                    stats.lost++;
                });
        };
        setTimeout(fn, idelay);
    }

    var maybe_start_qproc = function(obj) {
        if (qproc)
            return;
        var request = {
			chaincodeId: "speedt",
			fcn: "query",
			args: [],
			txId: null
        };
        
        var fn = function() {
            obj.channel.queryByChaincode(request)
                .then((response_payloads) => {
                    stats.queried++;
                    if (is_processing)
                        setTimeout(fn, qdelay);
                    else
                        qproc = false;
                })
                .catch(function (err) {
                    stats.lost++;
                });
        };
        setTimeout(fn, qdelay);
    };

    var maybe_start_processing = function(obj) {
        if (!is_processing || !conn_obj)
            return;
        maybe_start_iproc(conn_obj);
        maybe_start_qproc(conn_obj);
    };
    
    var conn_obj = null;
    var on_ready = function(obj) {
        conn_obj = obj;
        /*
		var eventHub = client.newEventHub();
		eventHub.setPeerAddr(options.peer_event_url);
		eventHub.connect();
		eventHub.registerBlockEvent(function(block) {
            console.log("EVENT");
            console.log(block);
        });
        */
        maybe_start_processing();
    };

    function getSubmitter(client, options) {
		var member;
		return client.getUserContext(options.enroll_id, true).then((user) => {
			if (user && user.isEnrolled()) {
				if (user._mspId !== options.msp_id) {
					console.log('[fcw] The msp id in KVS does not match the msp id passed to enroll. Need to clear the KVS.', user._mspId, options.msp_id);
				} else {
					console.log('[fcw] Successfully loaded enrollment from persistence');
					return user;
				}
			} else {
                var ca_client = new CaService(options.ca_url);

				member = new User(options.enroll_id);
				return ca_client.enroll({
					enrollmentID: options.enroll_id,
					enrollmentSecret: options.enroll_secret

				}).then((enrollment) => {
					console.log('[fcw] Successfully enrolled user \'' + options.enroll_id + '\'');
					return member.setEnrollment(enrollment.key, enrollment.certificate, options.msp_id);
				}).then(() => {
					return client.setUserContext(member);
				}).then(() => {
					return member;
				}).catch((err) => {
					console.log('[fcw] Failed to enroll and persist user. Error: ' + err.stack ? err.stack : err);
					throw new Error('Failed to obtain an enrolled user');
				});
			}
		});
	}

	FabricClient.newDefaultKeyValueStore({
		path: options.kvs_path
	}).then(function (store) {
		client.setStateStore(store);
		return getSubmitter(client, options);
	}).then(function (submitter) {
        console.log("submitter acquired");

		//channel.addOrderer(new Orderer(options.orderer_url, options.orderer_tls_opts));

        channel.addOrderer(new Orderer(options.orderer_url));
		channel.addPeer(new Peer(options.peer_url));
		console.log('added peer', options.peer_url);
		on_ready({ client: client, channel: channel, submitter: submitter });
		return;

	}).catch(function (err) {

		console.log('[fcw] Failed to get enrollment ' + options.uuid, err.stack ? err.stack : err);
		return;
	});

    
    return {
        set_queries_per_second: function(val) {
            qps = val;
            qdelay = 1000 / val;
        },
        set_invokes_per_second: function(val) {
            ips = val;
            idelay = 1000 / val;
        },        
        set_test_status: function(val) {
            if (val == is_processing)
                return;
            is_processing = val;
            maybe_start_processing(conn_obj);
        },
        gather_stats: function() {
            var res = Object.assign({}, stats);
            res["is_processing"] = is_processing;
            res["qps"] = qps;
            res["ips"] = ips;
            stats.queried = 0;
            stats.comitted = 0;
            stats.endorsed = 0;
            return res;
        }
    }
};
var WsConnector = function(server) {
    var wss = new ws.Server({ server: server });
    var on_msg = function(msg) {};
    var on_conn = function() {};
    var the_ws = false;
    
	wss.on('connection', function connection(ws) {
        if (the_ws)
            the_ws.close();
        the_ws = ws;
		ws.on('message', function incoming(msg) {
            on_msg(JSON.parse(msg));
        });
        on_conn();        
    });

    return {
        send_msg: function(msg) {
            if (!the_ws)
                return;
            msg = JSON.stringify(msg);
            try {
		        the_ws.send(msg);
            } catch (err) {
                console.log("ws connection is broken");
                the_ws = null;
            }
        },
        set_on_msg: function(cb) {
            on_msg = cb;
        },
        set_on_conn: function(cb) {
            on_conn = cb;
        }
    };
};
var TesterMan = function(wss) {
    var conf = [
        {
            "name": "AWS",
            "channel_id": "mychannel0",
            "orderer_url": "grpc://54.165.197.236:5007",
            "peer_url": "grpc://54.235.238.217:5004",
            "peer_event_url": "grpc://54.235.238.217:5005",
            "ca_url": "http://54.87.128.141:5001",
            "enroll_id": "admin",
            "enroll_secret": "adminpw",
            "msp_id": "org1.example.com",
            "kvs_path": "/tmp/bubu",
        }
    ];

    var testers = {};
    conf.forEach(function(e) {
        testers[e.name] = HyperledgerTester(e);
    });

    var send_stats = function(periodic) {
        var res = {};
        for (var key in testers) {
            res[key] = testers[key].gather_stats();            
        };
        wss.send_msg({"type": "stats", "contents": res});
        if (periodic)
            setTimeout(function() {send_stats(true)}, 1000);
    };

    wss.set_on_conn(function() {
        send_stats(false);
    });

    wss.set_on_msg(function(msg) {
        if (msg.type == "set_irate") {
            testers[msg.name].set_invokes_per_second(msg.val);
        }
        if (msg.type == "set_qrate") {
            testers[msg.name].set_queries_per_second(msg.val);
        }
        if (msg.type == "set_status") {
            testers[msg.name].set_test_status(msg.val);
            send_stats(false);
        }
    });
    
    send_stats(true);
};


app.use(function(req, res, next) {
    console.log(req.method, req.url);

    var is_auth = req.session.user && req.session.user.username;
    if (!is_auth && req.url != "/html/login.html" && 
        req.url != "/html/bad_auth.html" &&
        (req.url.startsWith("/html") || req.url == "/")) {
        res.redirect("/html/login.html");
    } else if (is_auth && req.url == "/html/login.html") {
        res.redirect("/html/main.html");
    } else {
        next();
    }

});

app.post("/login", function(req, res) {
    console.log("login", req.param("username"));
    if (req.param("username") == "admin" && req.param("password") == "admin2") {
        req.session.user = {
            "username": req.param("username")
        };
        res.redirect("/html/main.html");
    } else {
        res.redirect("/html/bad_auth.html");
    }
});


app.use(serve_static(path.join(__dirname, 'public')));

var server = http.createServer(app).listen(5005, function () { }); 
var wss = WsConnector(server);
var tman = TesterMan(wss);

console.log("listening on 5005");

